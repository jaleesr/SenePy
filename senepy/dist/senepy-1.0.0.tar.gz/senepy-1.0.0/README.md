Tools to score single cells based on their expression of senescnece markers.# senepy
